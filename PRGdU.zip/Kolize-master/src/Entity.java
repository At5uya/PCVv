public abstract class Entity {
    public static int X1;
    public static int Y1;
    public static int X;
    public static int Y;

    public static boolean colliding(String type) throws Exception {
        switch (type) {
            case "Wall":
                if (Knowledge.Y1 < Wall.Y1 || Player.Y1 < Wall.Y1) {
                    return true;
                } else {
                    return false;
                }
            case "Dunno":
                if (Knowledge.X1 < Player.X1 + Player.X &&
                        Knowledge.X1 + Knowledge.X > Player.X1 &&
                        Knowledge.Y1 < Player.Y1 + Player.Y &&
                        Knowledge.Y1 + Knowledge.Y > Player.Y1) {
                    return true;
                } else {
                    return false;
                }
            case "Player":
                if (Player.X1 < Knowledge.X1 + Knowledge.X &&
                        Player.X1 + Player.X > Knowledge.X1 &&
                        Player.Y1 < Knowledge.Y1 + Knowledge.Y &&
                        Player.Y1 + Player.Y > Knowledge.Y1) {
                    return true;
                } else {
                    return false;
                }
            default:
                throw new Exception("no parameter given");
        }
    }

    public static enum type {
        Player, Obstacle
    }
}