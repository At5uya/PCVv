public class main {
    public static void main(String[] args) {
        Player player = new Player();
        Knowledge dunn = new Knowledge();
        Wall wall = new Wall();

        try {
            System.out.println(Entity.colliding("Player"));
            System.out.println(Entity.colliding("Dunno"));
            System.out.println(Entity.colliding("Wall"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}