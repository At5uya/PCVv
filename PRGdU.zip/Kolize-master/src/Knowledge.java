public class Knowledge extends Entity {
    public Knowledge() {
        X1 = 15;
        polohaY1 = 8;
        X = 5;
        Y = 2;
        type Dunn = type.Player;
    }
}