public class Wall extends Entity {
    public void SouthBorder() {
        X1 = 0;
        polohaY1 = 0;
        X = 99;
        Y = 1;
        type Border = type.Obstacle;
    }
}