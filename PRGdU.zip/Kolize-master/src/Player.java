public class Player extends Entity {
    public Player() {
        X1 = 14;
        polohaY1 = 9;
        X = 3;
        Y = 2;
        type play = type.Player;
    }
}